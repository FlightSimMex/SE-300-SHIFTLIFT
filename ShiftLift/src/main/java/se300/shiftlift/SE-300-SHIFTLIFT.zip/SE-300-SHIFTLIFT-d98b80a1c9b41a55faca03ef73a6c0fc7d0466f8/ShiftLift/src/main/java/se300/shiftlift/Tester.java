package se300.shiftlift;

import java.util.Scanner;

public class Tester {

    Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args)
    {

        //Test Time ClaSAss
        // System.out.println("Testing Time class...");
        // System.err.println("Enter Start Time: ");
        // int start_time = Integer.parseInt(new Scanner(System.in).nextLine());
        // System.err.println("Enter End Time: ");
        // int end_time = Integer.parseInt(new Scanner(System.in).nextLine());
        // try {
        //     Time time = new Time(start_time, end_time);
        //     System.out.println("Time object created successfully with start time: " + time.getStart_time() + " and end time: " + time.getEnd_time());
        // } catch (IllegalArgumentException e) {
        //     System.err.println("Failed to create Time object: " + e.getMessage());
        // }

        //Test User Class (Has to be unmade abstarct first)
        // System.out.println("Testing User class...");
        // System.err.println("Enter Email: ");
        // String email = new Scanner(System.in).nextLine();
        // System.err.println("Enter Password: ");
        // String password = new Scanner(System.in).nextLine();
        // try {
        //     User user = new User(email, password);
        //     System.out.println("User object created successfully with username: " + user.getUsername() + ", initials: " + user.getInitials() + ", email: " + user.getEmail());
        // } catch (IllegalArgumentException e) {
        //     System.err.println("Failed to create User object: " + e.getMessage());
        // }
    }

}
